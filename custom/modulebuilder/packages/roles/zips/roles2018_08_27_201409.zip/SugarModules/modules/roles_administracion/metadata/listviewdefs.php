<?php
$module_name = 'roles_administracion';
$listViewDefs [$module_name] = 
array (
  'NOMBRE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_NOMBRE',
    'width' => '10%',
    'default' => true,
  ),
  'CORREO' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_CORREO',
    'width' => '10%',
    'default' => true,
  ),
  'NUMERO' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_NUMERO',
    'width' => '10%',
    'default' => true,
  ),
  'ESTATUS' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_ESTATUS',
    'width' => '10%',
    'default' => true,
  ),
);
;
?>
